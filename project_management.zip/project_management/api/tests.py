from rest_framework.test import APITestCase
from django.contrib.auth.models import User
from .models import Client, Project
from rest_framework import status

class ClientTests(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', password='testpassword')
        self.client.login(username='testuser', password='testpassword')
        self.client_data = {'client_name': 'company A'}
        self.client_instance = Client.objects.create(client_name='Nimap', created_by=self.user)

    def test_create_client(self):
        print("Client session:", self.client.session)  # Debug output
        response = self.client.post('/api/clients/', self.client_data, format='json')
        print(response.data)  # Debug output
        print(response.status_code)  # Debug output
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['client_name'], 'company A')

    def test_get_clients(self):
        response = self.client.get('/api/clients/')
        print(response.data)  # Debug output
        print(response.status_code)  # Debug output
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)

    def test_create_project(self):
        project_data = {
            'project_name': 'New Project',
            'users': [self.user.id]
        }
        response = self.client.post(f'/api/clients/{self.client_instance.id}/projects/', project_data, format='json')
        print(response.data)  # Debug output
        print(response.status_code)  # Debug output
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['project_name'], 'New Project')

    def test_list_projects_for_user(self):
        project = Project.objects.create(
            project_name='User Project',
            client=self.client_instance,
            created_by=self.user
        )
        project.users.set([self.user])
        response = self.client.get('/api/projects/')
        print(response.data)  # Debug output
        print(response.status_code)  # Debug output
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
